import { useCallback, useEffect, useRef, useState } from "react";
import { HillAudio } from "./audio";
import { GarageOverlay } from "./components/GarageOverlay";
import { HillControls } from "./components/HillControls";
import { FuelIcon, FullscreenIcon, PausePlayIcon, RestartIcon, SkullIcon, SoundIcon } from "./components/Icons";
import { HillSimulation } from "./physics";
import { renderHillScene, VIEW_HEIGHT, VIEW_WIDTH } from "./renderer";
import { loadProgress, saveProgress } from "./storage";
import type { GameOverReason, GamePhase, HudSnapshot, SavedProgress, StageId, UpgradeKey, VehicleId } from "./types";
import { getUpgradeCost, STAGE_MAP, VEHICLE_MAP } from "./vehicles";

function initialSnapshot(progress: SavedProgress): HudSnapshot {
  return {
    fuel: 100,
    lowFuel: false,
    outOfFuel: false,
    distance: 0,
    bestDistance: progress.bestDistances[progress.selectedStage],
    runCoins: 0,
    totalCoins: progress.coins,
    speedKmh: 0,
    rpm: 0.14,
    boost: 0,
    flips: 0,
    airBonusTotal: 0,
    newRecord: false,
    gameOverReason: null,
    deathCause: null,
    nextFuelMeters: 125,
  };
}

export default function App() {
  const [progress, setProgress] = useState<SavedProgress>(loadProgress);
  const progressRef = useRef<SavedProgress>(progress);
  progressRef.current = progress;

  const [phase, setPhase] = useState<GamePhase>("menu");
  const phaseRef = useRef<GamePhase>("menu");
  phaseRef.current = phase;

  const [hud, setHud] = useState<HudSnapshot>(() => initialSnapshot(progress));
  const [gasVisual, setGasVisual] = useState(false);
  const [brakeVisual, setBrakeVisual] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HillAudio>(new HillAudio());
  const simRef = useRef<HillSimulation | null>(null);
  const gameOverTimeoutRef = useRef<number | null>(null);

  // Multi-source input tracking (supports simultaneous keyboard + multi-touch pedals)
  const gasSources = useRef(new Set<string>());
  const brakeSources = useRef(new Set<string>());

  const syncVisualControls = useCallback(() => {
    setGasVisual(gasSources.current.size > 0);
    setBrakeVisual(brakeSources.current.size > 0);
  }, []);

  const clearControls = useCallback(() => {
    gasSources.current.clear();
    brakeSources.current.clear();
    setGasVisual(false);
    setBrakeVisual(false);
  }, []);

  const setControl = useCallback(
    (source: string, which: "gas" | "brake", pressed: boolean) => {
      audioRef.current.unlock();
      const set = which === "gas" ? gasSources.current : brakeSources.current;
      if (pressed) {
        if (phaseRef.current !== "playing") return;
        set.add(source);
      } else {
        set.delete(source);
      }
      syncVisualControls();
    },
    [syncVisualControls],
  );

  const updateProgress = useCallback((updater: (prev: SavedProgress) => SavedProgress) => {
    setProgress((prev) => {
      const next = updater(prev);
      progressRef.current = next;
      saveProgress(next);
      return next;
    });
  }, []);

  const createSimulation = useCallback(
    (vehicleId: VehicleId, stageId: StageId) => {
      if (gameOverTimeoutRef.current !== null) {
        window.clearTimeout(gameOverTimeoutRef.current);
        gameOverTimeoutRef.current = null;
      }
      const p = progressRef.current;
      const spec = VEHICLE_MAP[vehicleId];
      const stage = STAGE_MAP[stageId];
      const sim = new HillSimulation(
        spec,
        stage,
        p.upgrades[vehicleId],
        p.bestDistances[stageId],
        {
          onSound: (cue) => audioRef.current.cue(cue),
          onCoinsEarned: (amount) => {
            updateProgress((prev) => ({ ...prev, coins: prev.coins + amount }));
          },
          onGameOver: (reason: GameOverReason, finalDistance: number) => {
            clearControls();
            updateProgress((prev) => {
              const oldBest = prev.bestDistances[stageId];
              if (finalDistance <= oldBest) return prev;
              return {
                ...prev,
                bestDistances: { ...prev.bestDistances, [stageId]: finalDistance },
              };
            });
            // Short dramatic slow-mo pause on rollover death so player sees the YOU DIED banner & overturned vehicle
            const delay = reason === "died" ? 1100 : 650;
            gameOverTimeoutRef.current = window.setTimeout(() => {
              if (phaseRef.current === "playing") {
                phaseRef.current = "gameover";
                setPhase("gameover");
              }
            }, delay);
          },
        },
      );
      simRef.current = sim;
      setHud(sim.getSnapshot(p.coins));
    },
    [clearControls, updateProgress],
  );

  // Initialize simulation on mount & sync audio preference
  useEffect(() => {
    audioRef.current.setEnabled(progressRef.current.soundOn);
    createSimulation(progressRef.current.selectedVehicle, progressRef.current.selectedStage);
    const audio = audioRef.current;
    return () => {
      if (gameOverTimeoutRef.current !== null) {
        window.clearTimeout(gameOverTimeoutRef.current);
      }
      audio.dispose();
    };
  }, [createSimulation]);

  // Main requestAnimationFrame simulation & render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    const updateCanvasSize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(VIEW_WIDTH, Math.round(rect.width * dpr));
      canvas.height = Math.max(VIEW_HEIGHT, Math.round(rect.height * dpr));
    };
    updateCanvasSize();

    const ro = new ResizeObserver(updateCanvasSize);
    ro.observe(canvas);

    let frameId = 0;
    let lastTime = 0;
    let lastHudPush = 0;

    const loop = (now: number) => {
      const dt = lastTime ? Math.min(0.05, (now - lastTime) / 1000) : 0.016;
      lastTime = now;

      const sim = simRef.current;
      const mode = phaseRef.current;

      if (sim) {
        if (mode === "playing") {
          sim.update(
            dt,
            {
              gas: gasSources.current.size > 0,
              brake: brakeSources.current.size > 0,
            },
            false,
          );
          audioRef.current.updateEngine(
            sim.spec.engineSound,
            sim.rpm,
            gasSources.current.size > 0,
            !sim.ended,
            sim.outOfFuel,
          );
        } else if (mode === "menu") {
          sim.update(dt, { gas: false, brake: false }, true);
          audioRef.current.updateEngine(sim.spec.engineSound, 0.12, false, false, false);
        } else {
          audioRef.current.updateEngine(sim.spec.engineSound, 0, false, false, false);
        }

        renderHillScene(ctx, sim);

        if (now - lastHudPush >= 60) {
          setHud(sim.getSnapshot(progressRef.current.coins));
          lastHudPush = now;
        }
      }

      frameId = window.requestAnimationFrame(loop);
    };

    frameId = window.requestAnimationFrame(loop);

    const handleBlur = () => {
      clearControls();
      if (phaseRef.current === "playing" && !simRef.current?.ended) {
        phaseRef.current = "paused";
        setPhase("paused");
      }
    };
    const handleVis = () => {
      if (document.hidden) handleBlur();
    };
    window.addEventListener("blur", handleBlur);
    document.addEventListener("visibilitychange", handleVis);

    return () => {
      ro.disconnect();
      window.cancelAnimationFrame(frameId);
      window.removeEventListener("blur", handleBlur);
      document.removeEventListener("visibilitychange", handleVis);
    };
  }, [clearControls]);

  const startRun = useCallback(() => {
    audioRef.current.unlock();
    audioRef.current.cue("click");
    clearControls();
    const p = progressRef.current;
    createSimulation(p.selectedVehicle, p.selectedStage);
    phaseRef.current = "playing";
    setPhase("playing");
  }, [clearControls, createSimulation]);

  const openGarage = useCallback(() => {
    audioRef.current.cue("click");
    clearControls();
    const p = progressRef.current;
    createSimulation(p.selectedVehicle, p.selectedStage);
    phaseRef.current = "menu";
    setPhase("menu");
  }, [clearControls, createSimulation]);

  const pauseRun = useCallback(() => {
    if (phaseRef.current !== "playing" || simRef.current?.ended) return;
    audioRef.current.cue("click");
    clearControls();
    phaseRef.current = "paused";
    setPhase("paused");
  }, [clearControls]);

  const resumeRun = useCallback(() => {
    if (phaseRef.current !== "paused") return;
    audioRef.current.unlock();
    audioRef.current.cue("click");
    phaseRef.current = "playing";
    setPhase("playing");
  }, []);

  const selectVehicle = useCallback(
    (id: VehicleId) => {
      audioRef.current.unlock();
      audioRef.current.cue("click");
      updateProgress((prev) => ({ ...prev, selectedVehicle: id }));
      createSimulation(id, progressRef.current.selectedStage);
    },
    [createSimulation, updateProgress],
  );

  const selectStage = useCallback(
    (id: StageId) => {
      audioRef.current.unlock();
      audioRef.current.cue("click");
      updateProgress((prev) => ({ ...prev, selectedStage: id }));
      createSimulation(progressRef.current.selectedVehicle, id);
    },
    [createSimulation, updateProgress],
  );

  const buyUpgrade = useCallback(
    (key: UpgradeKey) => {
      audioRef.current.unlock();
      const p = progressRef.current;
      const vid = p.selectedVehicle;
      const lvl = p.upgrades[vid][key];
      const cost = getUpgradeCost(key, lvl);
      if (cost === null || p.coins < cost) return;

      audioRef.current.cue("upgrade");
      updateProgress((prev) => ({
        ...prev,
        coins: prev.coins - cost,
        upgrades: {
          ...prev.upgrades,
          [vid]: {
            ...prev.upgrades[vid],
            [key]: lvl + 1,
          },
        },
      }));
      // Refresh sim stats live
      createSimulation(vid, p.selectedStage);
    },
    [createSimulation, updateProgress],
  );

  const toggleSound = useCallback(() => {
    const next = !progressRef.current.soundOn;
    audioRef.current.setEnabled(next);
    if (next) audioRef.current.cue("click");
    updateProgress((prev) => ({ ...prev, soundOn: next }));
  }, [updateProgress]);

  const toggleFullscreen = useCallback(async () => {
    const el = stageRef.current;
    if (!el) return;
    if (document.fullscreenElement === el) {
      await document.exitFullscreen().catch(() => {});
    } else if (typeof el.requestFullscreen === "function") {
      await el.requestFullscreen().catch(() => {});
    }
  }, []);

  useEffect(() => {
    const onFs = () => setIsFullscreen(document.fullscreenElement === stageRef.current);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // Keyboard bindings matching authentic Hill Climb Racing controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.altKey || e.ctrlKey || e.metaKey) return;
      const code = e.code;
      const mode = phaseRef.current;

      if (code === "ArrowRight" || code === "KeyD" || code === "ArrowUp" || code === "KeyW") {
        if (mode === "playing") {
          e.preventDefault();
          setControl(`key-${code}`, "gas", true);
        }
      } else if (code === "ArrowLeft" || code === "KeyA" || code === "ArrowDown" || code === "KeyS") {
        if (mode === "playing") {
          e.preventDefault();
          setControl(`key-${code}`, "brake", true);
        }
      } else if ((code === "KeyP" || code === "Escape") && !e.repeat) {
        if (mode === "playing") {
          e.preventDefault();
          pauseRun();
        } else if (mode === "paused") {
          e.preventDefault();
          resumeRun();
        }
      } else if (code === "KeyR" && !e.repeat && (mode === "playing" || mode === "paused" || mode === "gameover")) {
        e.preventDefault();
        startRun();
      } else if (code === "Enter" && !e.repeat) {
        const target = e.target instanceof HTMLElement ? e.target : null;
        if (target?.closest("button")) return;
        if (mode === "menu" || mode === "gameover") {
          e.preventDefault();
          startRun();
        } else if (mode === "paused") {
          e.preventDefault();
          resumeRun();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      if (code === "ArrowRight" || code === "KeyD" || code === "ArrowUp" || code === "KeyW") {
        setControl(`key-${code}`, "gas", false);
      } else if (code === "ArrowLeft" || code === "KeyA" || code === "ArrowDown" || code === "KeyS") {
        setControl(`key-${code}`, "brake", false);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [pauseRun, resumeRun, setControl, startRun]);

  const activeVehicle = VEHICLE_MAP[progress.selectedVehicle];
  const activeStage = STAGE_MAP[progress.selectedStage];
  const fuelPercent = Math.max(0, Math.min(100, hud.fuel));
  const fuelColor = fuelPercent > 45 ? "#22c55e" : fuelPercent > 22 ? "#facc15" : "#ef4444";

  return (
    <div className="hc-viewport">
      {/* Strictly enforced 16:9 Game Stage */}
      <main
        ref={stageRef}
        className={`hc-stage${isFullscreen ? " is-fullscreen" : ""}`}
        data-phase={phase}
        aria-label="Hill Climb Legends 16:9 Game"
      >
        <canvas ref={canvasRef} className="hc-canvas" />

        {/* GARAGE / TITLE OVERLAY */}
        {phase === "menu" && (
          <GarageOverlay
            selectedVehicle={progress.selectedVehicle}
            selectedStage={progress.selectedStage}
            coins={progress.coins}
            bestDistances={progress.bestDistances}
            upgrades={progress.upgrades}
            soundOn={progress.soundOn}
            isFullscreen={isFullscreen}
            onToggleSound={toggleSound}
            onToggleFullscreen={() => void toggleFullscreen()}
            onSelectVehicle={selectVehicle}
            onSelectStage={selectStage}
            onUpgrade={buyUpgrade}
            onPlay={startRun}
          />
        )}

        {/* LIVE GAMEPLAY HUD & PEDAL CONTROLS */}
        {(phase === "playing" || phase === "paused") && (
          <>
            <header className="hc-hud">
              {/* Left: Fuel Bar + Coins */}
              <div className="hc-hud-left">
                <div className={`hc-fuel-box${hud.lowFuel || hud.outOfFuel ? " is-low" : ""}`}>
                  <span className="hc-fuel-icon" aria-hidden="true">
                    <FuelIcon />
                  </span>
                  <div className="hc-fuel-track" role="meter" aria-label="Fuel" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(fuelPercent)}>
                    <div
                      className="hc-fuel-fill"
                      style={{ width: `${fuelPercent}%`, backgroundColor: fuelColor }}
                    />
                    <span className="hc-fuel-text">
                      {hud.outOfFuel ? "EMPTY!" : hud.lowFuel ? "LOW FUEL!" : "FUEL"}
                    </span>
                  </div>
                </div>

                <div className="hc-coins-pill">
                  <span className="hc-coin-dot">$</span>
                  <strong>{progress.coins.toLocaleString("en-US")}</strong>
                </div>
              </div>

              {/* Center: Distance & Best */}
              <div className="hc-hud-center">
                <div className="hc-dist-readout">
                  <strong>{hud.distance}m</strong>
                  <span>BEST {hud.bestDistance}m</span>
                </div>
                <div className="hc-veh-chip">
                  <span>{activeVehicle.name}</span>
                  <i>•</i>
                  <span>{activeStage.name}</span>
                </div>
              </div>

              {/* Right: Action Buttons */}
              <div className="hc-hud-right">
                <button
                  type="button"
                  className="hc-icon-btn"
                  onClick={startRun}
                  aria-label="Restart run"
                  title="Restart (R)"
                >
                  <RestartIcon />
                </button>
                <button
                  type="button"
                  className="hc-icon-btn"
                  onClick={toggleSound}
                  aria-label={progress.soundOn ? "Mute sound" : "Enable sound"}
                  title="Toggle Sound"
                >
                  <SoundIcon on={progress.soundOn} />
                </button>
                <button
                  type="button"
                  className="hc-icon-btn"
                  onClick={() => void toggleFullscreen()}
                  aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
                  title="Fullscreen"
                >
                  <FullscreenIcon active={isFullscreen} />
                </button>
                <button
                  type="button"
                  className="hc-icon-btn hc-icon-btn--accent"
                  onClick={phase === "paused" ? resumeRun : pauseRun}
                  aria-label={phase === "paused" ? "Resume game" : "Pause game"}
                  title="Pause (P)"
                >
                  <PausePlayIcon paused={phase === "paused"} />
                </button>
              </div>
            </header>

            {/* Dramatic Live Rollover YOU DIED Banner during slow-mo crash */}
            {phase === "playing" && hud.gameOverReason === "died" && (
              <div className="hc-died-banner" role="alert">
                <span className="hc-died-skull">
                  <SkullIcon />
                </span>
                <div>
                  <strong>YOU DIED!</strong>
                  <span>
                    {activeVehicle.category === "bike" ? "BIKE FLIPPED & CRASHED" : "CAR OVERTURNED (PALAT GAYI)"}
                  </span>
                </div>
              </div>
            )}

            {/* Helpful Right-Edge Fuel Pointer when fuel < 48% */}
            {phase === "playing" && !hud.gameOverReason && fuelPercent < 48 && hud.nextFuelMeters < 220 && hud.nextFuelMeters > 8 && (
              <div className={`hc-fuel-pointer${hud.lowFuel ? " is-urgent" : ""}`}>
                <span className="hc-fuel-pointer-icon">
                  <FuelIcon />
                </span>
                <span>FUEL</span>
                <strong>{hud.nextFuelMeters}m →</strong>
              </div>
            )}

            {/* Authentic Hill Climb Racing Bottom Pedals & Twin Gauges */}
            <HillControls
              gasActive={gasVisual}
              brakeActive={brakeVisual}
              rpm={hud.rpm}
              boost={hud.boost}
              speedKmh={hud.speedKmh}
              disabled={phase !== "playing"}
              onControl={setControl}
            />
          </>
        )}

        {/* PAUSE MODAL */}
        {phase === "paused" && (
          <div className="hc-modal-backdrop">
            <div className="hc-modal" role="dialog" aria-labelledby="pause-heading">
              <span className="hc-modal-tag">
                {activeVehicle.name} • {activeStage.name}
              </span>
              <h2 id="pause-heading">PAUSED</h2>
              <p className="hc-modal-sub">
                Distance: <strong>{hud.distance}m</strong> • Run Coins: <strong>+{hud.runCoins}</strong>
              </p>
              <div className="hc-modal-actions">
                <button type="button" className="hc-btn hc-btn--primary" onClick={resumeRun}>
                  RESUME
                </button>
                <button type="button" className="hc-btn hc-btn--secondary" onClick={startRun}>
                  RESTART
                </button>
                <button type="button" className="hc-btn hc-btn--ghost" onClick={openGarage}>
                  GARAGE / CARS
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GAME OVER MODAL */}
        {phase === "gameover" && (
          <div className="hc-modal-backdrop">
            <div className="hc-modal hc-modal--gameover" role="dialog" aria-labelledby="over-heading">
              <span className="hc-modal-tag hc-modal-tag--danger">
                {hud.newRecord
                  ? `NEW RECORD • ${activeVehicle.name}`
                  : hud.gameOverReason === "died"
                    ? `${activeVehicle.name} OVERTURNED`
                    : `${activeVehicle.name} • EMPTY TANK`}
              </span>
              <h2
                id="over-heading"
                className={hud.gameOverReason === "died" ? "hc-heading-died" : undefined}
              >
                {hud.gameOverReason === "out_of_fuel" ? "OUT OF FUEL" : "YOU DIED"}
              </h2>
              <p className="hc-modal-sub">
                {hud.gameOverReason === "out_of_fuel"
                  ? "Fuel ran empty! Collect red fuel cans or upgrade your Fuel Tank."
                  : activeVehicle.category === "bike"
                    ? "Your bike flipped upside down on the road!"
                    : "Your car overturned onto its roof!"}
              </p>

              <div className="hc-stats-grid">
                <div className="hc-stat-box">
                  <span>DISTANCE</span>
                  <strong>{hud.distance}m</strong>
                </div>
                <div className="hc-stat-box">
                  <span>BEST</span>
                  <strong>{hud.bestDistance}m</strong>
                </div>
                <div className="hc-stat-box">
                  <span>COINS EARNED</span>
                  <strong className="is-gold">+{hud.runCoins}</strong>
                </div>
                <div className="hc-stat-box">
                  <span>FLIPS</span>
                  <strong>{hud.flips}</strong>
                </div>
              </div>

              <div className="hc-modal-actions">
                <button type="button" className="hc-btn hc-btn--primary" onClick={startRun}>
                  TRY AGAIN
                </button>
                <button type="button" className="hc-btn hc-btn--secondary" onClick={openGarage}>
                  GARAGE &amp; UPGRADES
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
