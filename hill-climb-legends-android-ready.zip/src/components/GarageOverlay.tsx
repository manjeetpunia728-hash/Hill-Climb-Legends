import { useEffect, useRef } from "react";
import type { StageId, UpgradeKey, UpgradeLevels, VehicleId, VehicleSpec } from "../types";
import { renderVehiclePreview } from "../vehicleArt";
import { getUpgradeCost, MAX_UPGRADE_LEVEL, STAGES, UPGRADE_LABELS, VEHICLES } from "../vehicles";
import { FullscreenIcon, SoundIcon } from "./Icons";

interface GarageOverlayProps {
  selectedVehicle: VehicleId;
  selectedStage: StageId;
  coins: number;
  bestDistances: Record<StageId, number>;
  upgrades: Record<VehicleId, UpgradeLevels>;
  soundOn: boolean;
  isFullscreen: boolean;
  onToggleSound: () => void;
  onToggleFullscreen: () => void;
  onSelectVehicle: (id: VehicleId) => void;
  onSelectStage: (id: StageId) => void;
  onUpgrade: (key: UpgradeKey) => void;
  onPlay: () => void;
}

function VehicleThumb({ spec }: { spec: VehicleSpec }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (ref.current) {
      renderVehiclePreview(ref.current, spec);
    }
  }, [spec]);

  return <canvas ref={ref} width={240} height={126} className="hc-veh-thumb" aria-hidden="true" />;
}

const UPGRADE_KEYS: UpgradeKey[] = ["engine", "suspension", "tires", "fuel"];

export function GarageOverlay({
  selectedVehicle,
  selectedStage,
  coins,
  bestDistances,
  upgrades,
  soundOn,
  isFullscreen,
  onToggleSound,
  onToggleFullscreen,
  onSelectVehicle,
  onSelectStage,
  onUpgrade,
  onPlay,
}: GarageOverlayProps) {
  const currentUpgrades = upgrades[selectedVehicle];
  const currentBest = bestDistances[selectedStage];

  return (
    <div className="hc-garage">
      {/* Top Header Strip */}
      <div className="hc-garage-header">
        <div className="hc-brand">
          <span className="hc-brand-kicker">16:9 PHYSICS RACER</span>
          <h1 className="hc-brand-title">
            HILL CLIMB <em>LEGENDS</em>
          </h1>
        </div>

        {/* Stage Selector Pills */}
        <div className="hc-stage-tabs" role="radiogroup" aria-label="Select stage">
          {STAGES.map((st) => {
            const active = st.id === selectedStage;
            return (
              <button
                key={st.id}
                type="button"
                role="radio"
                aria-checked={active}
                className={`hc-stage-pill${active ? " is-active" : ""}`}
                onClick={() => onSelectStage(st.id)}
              >
                <span className="hc-stage-name">{st.name}</span>
                <span className="hc-stage-best">
                  {bestDistances[st.id] > 0 ? `BEST ${bestDistances[st.id]}m` : st.subtitle}
                </span>
              </button>
            );
          })}
        </div>

        {/* Coin Wallet + Sound/Fullscreen */}
        <div className="hc-header-right">
          <div className="hc-wallet" aria-label={`${coins} coins`}>
            <span className="hc-coin-dot">$</span>
            <strong>{coins.toLocaleString("en-US")}</strong>
          </div>
          <button
            type="button"
            className="hc-icon-btn"
            onClick={onToggleSound}
            aria-label={soundOn ? "Mute sound" : "Enable sound"}
            title={soundOn ? "Sound On" : "Sound Off"}
          >
            <SoundIcon on={soundOn} />
          </button>
          <button
            type="button"
            className="hc-icon-btn"
            onClick={onToggleFullscreen}
            aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
            title="Fullscreen"
          >
            <FullscreenIcon active={isFullscreen} />
          </button>
        </div>
      </div>

      {/* Bottom Interactive Garage Dock (leaves middle canvas clear so idling vehicle shines!) */}
      <div className="hc-garage-dock">
        {/* 4 Cars + 1 Bike Selector */}
        <div className="hc-vehicle-row" role="radiogroup" aria-label="Select vehicle">
          {VEHICLES.map((v) => {
            const active = v.id === selectedVehicle;
            return (
              <button
                key={v.id}
                type="button"
                role="radio"
                aria-checked={active}
                className={`hc-veh-card${active ? " is-active" : ""}${v.category === "bike" ? " hc-veh-card--bike" : ""}`}
                onClick={() => onSelectVehicle(v.id)}
              >
                <span className="hc-veh-badge">{v.badge}</span>
                <VehicleThumb spec={v} />
                <div className="hc-veh-meta">
                  <strong>{v.name}</strong>
                  <span>{v.subtitle}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Upgrades Strip + Play CTA */}
        <div className="hc-dock-bottom">
          <div className="hc-upgrades-row" aria-label="Vehicle upgrades">
            {UPGRADE_KEYS.map((key) => {
              const level = currentUpgrades[key];
              const cost = getUpgradeCost(key, level);
              const maxed = cost === null;
              const canAfford = cost !== null && coins >= cost;
              return (
                <button
                  key={key}
                  type="button"
                  className={`hc-upg-btn${maxed ? " is-maxed" : ""}${canAfford ? " is-affordable" : ""}`}
                  disabled={maxed || !canAfford}
                  onClick={() => onUpgrade(key)}
                  title={UPGRADE_LABELS[key].desc}
                >
                  <div className="hc-upg-head">
                    <span>{UPGRADE_LABELS[key].name}</span>
                    <strong>{maxed ? "MAX" : `${cost}`}</strong>
                  </div>
                  <div className="hc-upg-pips" aria-hidden="true">
                    {Array.from({ length: MAX_UPGRADE_LEVEL }, (_, i) => (
                      <i key={i} className={i < level ? "is-lit" : ""} />
                    ))}
                  </div>
                </button>
              );
            })}
          </div>

          <button type="button" className="hc-play-btn" onClick={onPlay}>
            <span className="hc-play-main">DRIVE!</span>
            <span className="hc-play-sub">
              {currentBest > 0 ? `BEAT ${currentBest}m` : "START CLIMB"}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
