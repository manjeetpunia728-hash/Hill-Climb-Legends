import type { PointerEvent } from "react";

interface HillControlsProps {
  gasActive: boolean;
  brakeActive: boolean;
  rpm: number;
  boost: number;
  speedKmh: number;
  disabled: boolean;
  onControl: (source: string, which: "gas" | "brake", pressed: boolean) => void;
}

function AnalogDial({
  label,
  value,
  subValue,
  accent,
  redlineStart = 0.78,
}: {
  label: string;
  value: number; // 0..1
  subValue: string;
  accent: string;
  redlineStart?: number;
}) {
  const clamped = Math.max(0, Math.min(1, value));
  // Needle sweeps from -125 deg to +125 deg
  const angleDeg = -125 + clamped * 250;

  return (
    <div className="hc-dial" aria-hidden="true">
      <svg viewBox="0 0 110 110" className="hc-dial-svg">
        <defs>
          <radialGradient id={`dial-bg-${label}`} cx="50%" cy="45%" r="55%">
            <stop offset="0%" stopColor="#2a303b" />
            <stop offset="100%" stopColor="#0e1218" />
          </radialGradient>
        </defs>
        {/* Metallic bezel */}
        <circle cx="55" cy="55" r="51" fill="#475569" stroke="#94a3b8" strokeWidth="2.5" />
        <circle cx="55" cy="55" r="45" fill={`url(#dial-bg-${label})`} stroke="#020617" strokeWidth="2" />

        {/* Tick marks */}
        {Array.from({ length: 11 }, (_, i) => {
          const t = i / 10;
          const a = ((-125 + t * 250 - 90) * Math.PI) / 180;
          const isRed = t >= redlineStart;
          const r1 = i % 2 === 0 ? 33 : 36;
          const r2 = 41;
          return (
            <line
              key={i}
              x1={55 + Math.cos(a) * r1}
              y1={55 + Math.sin(a) * r1}
              x2={55 + Math.cos(a) * r2}
              y2={55 + Math.sin(a) * r2}
              stroke={isRed ? "#ef4444" : "#e2e8f0"}
              strokeWidth={i % 2 === 0 ? 2.6 : 1.5}
              strokeLinecap="round"
            />
          );
        })}

        {/* Label & digital value */}
        <text
          x="55"
          y="40"
          textAnchor="middle"
          fill="#94a3b8"
          fontSize="10"
          fontWeight="700"
          fontFamily="'IBM Plex Mono', monospace"
        >
          {label}
        </text>
        <text
          x="55"
          y="86"
          textAnchor="middle"
          fill="#f8fafc"
          fontSize="12"
          fontWeight="700"
          fontFamily="'IBM Plex Mono', monospace"
        >
          {subValue}
        </text>

        {/* Sweeping Needle */}
        <g transform={`translate(55, 55) rotate(${angleDeg})`}>
          <line x1="0" y1="8" x2="0" y2="-35" stroke={accent} strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="0" cy="0" r="6" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1.8" />
        </g>
      </svg>
    </div>
  );
}

export function HillControls({
  gasActive,
  brakeActive,
  rpm,
  boost,
  speedKmh,
  disabled,
  onControl,
}: HillControlsProps) {
  const bindPedal = (which: "gas" | "brake") => ({
    onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
      if (disabled || e.button !== 0) return;
      e.preventDefault();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore pointer capture error in headless environments
      }
      onControl(`ptr-${e.pointerId}`, which, true);
    },
    onPointerUp: (e: PointerEvent<HTMLButtonElement>) => {
      onControl(`ptr-${e.pointerId}`, which, false);
    },
    onPointerCancel: (e: PointerEvent<HTMLButtonElement>) => {
      onControl(`ptr-${e.pointerId}`, which, false);
    },
    onLostPointerCapture: (e: PointerEvent<HTMLButtonElement>) => {
      onControl(`ptr-${e.pointerId}`, which, false);
    },
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
  });

  return (
    <div className="hc-bottom-controls">
      {/* Left Pedal — BRAKE / REVERSE / NOSE DOWN */}
      <button
        type="button"
        aria-label="Brake pedal"
        aria-pressed={brakeActive}
        disabled={disabled}
        className={`hc-pedal hc-pedal--brake${brakeActive ? " is-pressed" : ""}`}
        {...bindPedal("brake")}
      >
        <span className="hc-pedal-title">BRAKE</span>
        <span className="hc-pedal-plate">
          <i />
          <i />
          <i />
          <i />
        </span>
        <span className="hc-pedal-key">◀ / A</span>
      </button>

      {/* Center Twin Analog Gauges (RPM & SPEED/BOOST) */}
      <div className="hc-gauges">
        <AnalogDial
          label="RPM"
          value={rpm}
          subValue={`${Math.round(rpm * 7 + 1)}K`}
          accent="#ef4444"
          redlineStart={0.75}
        />
        <AnalogDial
          label="SPEED"
          value={Math.min(1, Math.max(speedKmh / 110, boost * 0.65))}
          subValue={`${speedKmh}`}
          accent="#f59e0b"
          redlineStart={0.85}
        />
      </div>

      {/* Right Pedal — GAS / WHEELIE / NOSE UP */}
      <button
        type="button"
        aria-label="Gas pedal"
        aria-pressed={gasActive}
        disabled={disabled}
        className={`hc-pedal hc-pedal--gas${gasActive ? " is-pressed" : ""}`}
        {...bindPedal("gas")}
      >
        <span className="hc-pedal-title">GAS</span>
        <span className="hc-pedal-plate">
          <i />
          <i />
          <i />
          <i />
          <i />
        </span>
        <span className="hc-pedal-key">▶ / D</span>
      </button>
    </div>
  );
}
